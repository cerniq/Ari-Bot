module.exports = {
  PREFIX: '$', //prefix for the bot here
  owner: {
    id: '', //put your owner Id in here so you can bypass cooldown for the generator commands and use the nitrogen command
    username: 'greenbeanfien', // ur username here but this is just for display, doesn't actually have a function
    guild: '', //put your guild/server id here
  },

  channels: {
    generator: '', //ID of the generator channel
    nitro: '', //ID of the nitro generator channel
    twitch: '', //ID of the Twitch follows channel
    memberCounter: '', //ID of the member count channel
  },

  links: {
    HandlerInvite: 'https://disord.gg/laundrymat', //edit your own way 
    website: 'https://laundrymat.sellix.io',
    GenIcon: 'https://tenor.com/view/hasbulla-hasbullah-hasbik-trending-viral-gif-21894027', //G.I.F icon for the generator embed here
  },

  colors: {
    //keep these colors like this too make it look clean but feel free to change if  you feel like it
    Default: '#18191c',
    Red: '#ff0000',
    Yellow: '#daff00',
    Orange: '#ff8400',
    Green: '#71fd71',
    LightGreen: '#5ac18e',
  },

  emojis: {
    success: '<a:01moneybag:1021957129516630016>', //Emoji when succeding
    error: '<a:Siren_Red:903661321348853810>', //Emoji when wrong
    loading: '<a:loadingcircle:1023433939702005872>', //Emoji when loading
    arrow: '<a:pinkarrow:1021948211230949398>', //Arrow Emoji
    pingpong: '<a:caution:978012327997743114>', //Pingpong racket Emoji

    Generator: '<a:01moneybag:1021957129516630016>', //Generator emoji for !help embed
    Twitch: '<:Twitch:997138045583233064>', //Twitch emoji for !help embed
    Other: '<:Other:997137846055997542>', //Other emoji for !help embed
    Nitro: '<:nitroboost:978012279410925661>', //Nitro emoji for !help embed
  },

  Token: {
    Discord: '', //insert token here
  },

  blacklistedUsers: {
    ID: ['ID', 'ID2', 'ID3'], //Blacklist any users from the bot by putting their Id's in here
  }, //Just copy the pattern if you want to blacklist more people
};
